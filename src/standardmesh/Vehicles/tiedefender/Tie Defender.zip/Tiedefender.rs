subshader "Tiedefender_Material0" "StandardMesh/Default"
{
	lighting true;
	materialDiffuse 1 1 1;
	lightingSpecular false;
	texture "texture/Vehicles/TieInterceptor/tieinterceptor";
}

